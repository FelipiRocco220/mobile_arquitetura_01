# ARCH — Arquitetura Refatorada em Feature-First

## Estrutura Final

```
lib/
├── core/                           # Código compartilhado entre features
│   ├── error/
│   │   └── app_error.dart         # Exceções da aplicação
│   └── ...
│
├── features/                       # Features isoladas (cada uma é um mini-app)
│   └── todos/                      # Feature de TODOs
│       ├── data/                   # Camada de dados
│       │   ├── datasources/        # Abstrações + implementações de dados
│       │   │   ├── todo_remote_datasource.dart  # Acesso HTTP
│       │   │   └── todo_local_datasource.dart   # Acesso SharedPreferences
│       │   ├── models/             # Modelos para serialização/desserialização
│       │   │   └── todo_model.dart
│       │   └── repositories/       # Implementação do contrato domain
│       │       └── todo_repository_impl.dart
│       │
│       ├── domain/                 # Camada de negócio (independente de UI/DB)
│       │   ├── entities/           # Modelos puros de negócio
│       │   │   └── todo.dart
│       │   └── repositories/       # Interfaces/contratos de repositório
│       │       └── todo_repository.dart
│       │
│       ├── presentation/           # Camada de apresentação
│       │   ├── pages/              # Telas/páginas
│       │   │   └── todos_page.dart
│       │   ├── viewmodels/         # Estados e lógica de UI (Provider)
│       │   │   └── todo_viewmodel.dart
│       │   └── widgets/            # Componentes reutilizáveis
│       │       └── add_todo_dialog.dart
│       │
│       └── app_root.dart           # AppRoot da feature (facilita testes)
│
├── main.dart                       # Entry point - apenas setup de DI e MultiProvider
└── ...
```

---

## Fluxo de Dados (Diagrama)

```
┌─────────────────────────────────────────────────────────────────┐
│                    PRESENTATION LAYER                           │
│                  (UI Components & State)                         │
│                                                                  │
│    ┌────────────────────────────────────────────────────────┐  │
│    │  TodosPage (Stateful Widget)                           │  │
│    │  - Consome TodoViewModel via context.watch()           │  │
│    │  - Dispara ações: loadTodos(), addTodo(), toggle...    │  │
│    │  - PROIBIDO: chamar HTTP ou SharedPreferences          │  │
│    └────────┬───────────────────────────────────────────────┘  │
│             │ context.read/watch()                              │
│    ┌────────▼───────────────────────────────────────────────┐  │
│    │  TodoViewModel (ChangeNotifier)                         │  │
│    │  - Gerencia: isLoading, errorMessage, items[]           │  │
│    │  - Valida entrada (ex: título não vazio)                │  │
│    │  - Notifica listeners ao estado mudar                   │  │
│    │  - PROIBIDO: conhecer Widgets/BuildContext              │  │
│    └────────┬───────────────────────────────────────────────┘  │
└─────────────│──────────────────────────────────────────────────┘
              │ chama métodos
┌─────────────▼──────────────────────────────────────────────────┐
│             DOMAIN LAYER (Lógica de Negócio)                   │
│                                                                │
│    ┌────────────────────────────────────────────────────────┐ │
│    │  TodoRepository (interface)                            │ │
│    │  - Contrato: fetchTodos(), addTodo(),                 │ │
│    │             updateCompleted()                          │ │
│    │  - INDEPENDENTE de implementação                       │ │
│    └────────▲───────────────────────────────────────────────┘ │
│             │ implementado por                                  │
└─────────────┼──────────────────────────────────────────────────┘
              │
┌─────────────▼──────────────────────────────────────────────────┐
│             DATA LAYER (Acesso a Dados)                        │
│                                                                │
│    ┌────────────────────────────────────────────────────────┐ │
│    │  TodoRepositoryImpl                                    │ │
│    │  - Implementa TodoRepository                          │ │
│    │  - Coordena: RemoteDataSource + LocalDataSource       │ │
│    │  - Mapeia TodoModel -> Todo (entity)                  │ │
│    │  - Centraliza escolha remoto/local                    │ │
│    └────────┬─────────────────┬──────────────────────────────┘ │
│             │                 │                                 │
│    ┌────────▼─────────┐  ┌────▼──────────────────────────────┐ │
│    │ TodoRemoteData   │  │ TodoLocalDataSource               │ │
│    │ Source (HTTP)    │  │ (SharedPreferences)               │ │
│    │                  │  │                                   │ │
│    │ - fetchTodos()   │  │ - saveLastSync()                  │ │
│    │ - addTodo()      │  │ - getLastSync()                   │ │
│    │ - updateComp...()│  │                                   │ │
│    │               │  │                                   │ │
│    │ Retorna: List│  │ Retorna: DateTime?                  │ │
│    │ <TodoModel>  │  │                                   │ │
│    └──────────────┘  └───────────────────────────────────────┘ │
└────────────────────────────────────────────────────────────────┘
```

---

## Responsabilidades por Camada

### PRESENTATION (`presentation/`)
**O que faz:** Renderiza UI e captura input do usuário.

**Responsabilidades:**
- Widgets/Pages: Exibem data e disparam ações
- ViewModel: Gerencia estado, validações simples e notifica mudanças
- **PROIBIDO**: 
  - Chamar HTTP diretamente
  - Acessar SharedPreferences
  - Conhecer BuildContext fora de inicialização

**Arquivos:**
- `pages/todos_page.dart` → Tela principal
- `viewmodels/todo_viewmodel.dart` → Estado com ChangeNotifier
- `widgets/add_todo_dialog.dart` → Dialog para novo TODO

---

### DOMAIN (`domain/`)
**O que faz:** Define as regras de negócio e contratos.

**Responsabilidades:**
- `entities/todo.dart` → Modelos puros de negócio
- `repositories/todo_repository.dart` → Interface que define o contrato
- **VANTAGEM**: Não conhece Framework, DB, HTTP. Fácil testar!

**Características:**
- Independente de qualquer implementação
- Define o que o app faz (casos de uso)
- Entidades com lógica de negócio (ex: `copyWith()`)

---

### DATA (`data/`)
**O que faz:** Implementa acesso a dados e converte entre modelos.

**Subcamadas:**

#### `datasources/`
- **TodoRemoteDataSource**: HTTP via JSONPlaceholder
  - `fetchTodos()` → GET /todos
  - `addTodo(title)` → POST /todos
  - `updateCompleted(id, completed)` → PATCH /todos/$id
  
- **TodoLocalDataSource**: SharedPreferences
  - `saveLastSync(DateTime)` → Cache do último sincronismo
  - `getLastSync()` → Recupera timestamp

#### `models/`
- **TodoModel**: Estende `Todo (entity)`
  - `fromJson()` → Parse HTTP response
  - `toJson()` → Serializa se necessário

#### `repositories/`
- **TodoRepositoryImpl**: Implementa `TodoRepository`
  - Coordena remote + local
  - Mapeia `TodoModel` → `Todo`
  - Centraliza erros e retry logic

---

### CORE (`core/`)
**O que faz:** Compartilha código entre features.

**Conteúdo:**
- `error/app_error.dart` → Exceções customizadas

---

## Decisões de Arquitetura

### 1. Onde fica a validação?
VIEWMODEL (`presentation/viewmodels/`)
- Validações de UI (título não vazio)
- Feedback imediato ao usuário

Não fica em DataSource (seria muito cedo)
Não fica em Repository (seria muito específico para UI)

```dart
// Em TodoViewModel.addTodo():
if (title.trim().isEmpty) {
  errorMessage = 'Título não pode ser vazio.';
  notifyListeners();
  return;
}
```

### 2. Onde fica o parsing JSON?
DATA LAYER (`data/models/todo_model.dart`)
- `TodoModel.fromJson()` → Responsável por parse
- Retorna entidade domain limpa para ViewModel

```dart
// Em TodoRepositoryImpl.fetchTodos():
final models = await _remote.fetchTodos(); // List<TodoModel>
return TodoFetchResult(
  todos: models.map((m) => Todo(...)).toList(), // Converte
);
```

### 3. Como é tratado erro?
Propaga de DataSource → Repository → ViewModel
Feedback via `errorMessage` (ViewModel state)
UI exibe erro e botão "Tentar Novamente"
Rollback em toggle (pessimistic update + fallback)

```dart
// ViewModel.toggleCompleted():
try {
  await _repo.updateCompleted(...);
} catch (e) {
  items[idx] = old; // Rollback
  errorMessage = 'Falha ao atualizar: $e';
  notifyListeners();
}
```

### 4. Por que Feature-First e não por Layer?
| Estrutura por Layer | Feature-First |
|---|---|
| `lib/models/`, `lib/repos/`, `lib/screens/` | `lib/features/todos/{data,domain,presentation}` |
| Difícil escalar multi-feature | Cada feature isolada |
| Muitos imports cruzando camadas | Imports precisos dentro da feature |
| Difícil remover/testar uma feature | Fácil remover/testar |

Feature-First é melhor para projetos que crescem!

### 5. Onde fica AppRoot?
`features/todos/app_root.dart`
- Específico da feature (facilita testes isolados)
- `main.dart` apenas faz setup do Provider

### 6. Por que TodoRepositoryImpl, não abstract?
ViewModel usa implementação concreta:
```dart
final TodoRepositoryImpl _repo = TodoRepositoryImpl();
```

Em produção, seria melhor:
```dart
final TodoRepository _repo; // Injetar no construtor
TodoViewModel(this._repo); // Via GetIt ou Factory
```

Mas aqui está simplificado para o learning path!

---

## Fluxo de uma Ação (Exemplo: Carregar TODOs)

1. **UI** (TodosPage) → Chama `vm.loadTodos()`
2. **ViewModel** (TodoViewModel)
   - Seta `isLoading = true`
   - Notifica listeners → UI exibe spinner
3. **Repository** (TodoRepositoryImpl)
   - Chama `_remote.fetchTodos()` → GET JSON
   - Chama `_local.saveLastSync(now)` → Cache timestamp
   - Retorna `TodoFetchResult`
4. **ViewModel** recebe resultado
   - Mapeia items
   - Seta `lastSyncLabel`
   - Seta `isLoading = false`
   - Notifica listeners → UI atualiza
5. **UI** exibe lista de TODOs + timestamp

---

## Como Rodar

```bash
# 1. Restaurar dependências
flutter pub get

# 2. Rodar na plataforma desejada
flutter run

# 3. Para web (se configura em pubspec.yaml)
flutter run -d chrome

# 4. Testes (adicionar em analysis_options.yaml)
flutter test
```

---

## Checklist de Compliance

PROJETO
- [ ] Compila sem erros
- [ ] Roda no emulador/device
- [ ] Carrega TODO list ao iniciar
- [ ] Adiciona novo TODO
- [ ] Toggle completed funciona
- [ ] RefreshIndicator funciona (ícone refresh no AppBar)

ARQUITETURA
- [ ] UI não conhece HTTP/SharedPreferences
- [ ] ViewModel sem BuildContext (exceto strings)
- [ ] Repository escolhe remoto/local
- [ ] Imports seguem estrutura feature-first
- [ ] Domain é independente
- [ ] Erros são tratados e propagados

CÓDIGO
- [ ] Sem import de `../screens/` em `utils/`
- [ ] Sem import circular
- [ ] Nomes claros e convenções Dart respeitadas

---

## Melhorias Futuras

1. **Injeção de Dependência** → GetIt, Riverpod, ou Factory Pattern
2. **Testes Unitários** → Mock Repository, testar ViewModel isoladamente
3. **Testes de Integração** → golden tests, full flow
4. **Error Boundaries** → Widget genérico para erros
5. **Paginação** → Implementar limit/offset
6. **Local DB** → SQLite em vez de SharedPreferences (melhor queries)
7. **Sync Strategy** → Offline-first com queue de operações
